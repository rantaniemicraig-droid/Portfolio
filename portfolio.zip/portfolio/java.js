function downloadCV() {
    alert("The CV will now download. Thanks for visiting!");

    const link = document.createElement('a');
    link.href = "cv.pdf";              
    link.download = "cv.pdf";          
    link.click();
}